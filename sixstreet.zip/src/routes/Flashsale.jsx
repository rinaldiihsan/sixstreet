import React from 'react'

const Flashsale = () => {
  return (
    <div>
      
    </div>
  )
}

export default Flashsale
