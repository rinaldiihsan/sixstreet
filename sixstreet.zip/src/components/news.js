const news = [
  {
    imgSrc: '/dummy-news.png',
    title: 'SixStreet Unveils Latest Collection: Cutting-edge Fashion Pieces Hit the Runway',
    link: '/',
  },
  {
    imgSrc: '/dummy-news.png',
    title: 'SixStreet Unveils Latest Collection: Cutting-edge Fashion Pieces Hit the Runway',
    link: '/',
  },
  {
    imgSrc: '/dummy-news.png',
    title: 'SixStreet Unveils Latest Collection: Cutting-edge Fashion Pieces Hit the Runway',
    link: '/',
  },
];

export default news;
