import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

const SidebarFilter = ({ sidebarOpen, showSidebar }) => {
  return <div>SidebarFilter</div>;
};

export default SidebarFilter;
